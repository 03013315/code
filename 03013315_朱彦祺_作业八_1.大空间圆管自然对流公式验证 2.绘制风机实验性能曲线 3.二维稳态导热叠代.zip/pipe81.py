T0 = 290.5
D = 0.05
o = 0.01  #管壁厚度
L = 1.4
pi=3.141592653

def solveGr(T,v):
    Gr=(9.806*(1/T)*(T-T0)*D**3/v**2)
    return Gr
def solveh(T,P):
    h=(P/((T-T0)*D*pi*L)-0.8*(5.67*( 10**(-8) )*(T**4-T0**4))/(T-T0))
    return h
def fromhsolveNu(T,P,landa,k):
    h=solveh(T,P)
    Nu=k*D/landa
    return Nu

def solve1(T, P, v, Pr):
    Gr= solveGr(T,v)
    Nu=0.022*(Gr*Pr)**0.5682
    return Nu
    
def solve2(T, P, v, Pr): 
    Gr= solveGr(T,v)   
    Nu=0.48*(Gr*Pr)**0.25
    return Nu
    
def solve3(T, P, v, Pr):
    Gr= solveGr(T,v)
    Nu=0.518*((1+(0.599/Pr)**0.6)**(-5/12)) * (Gr*Pr)**(1/4)
    return Nu
    
def solve4(T, P, v, Pr):
    Gr= solveGr(T,v)
    Nu=0.34*(Gr*Pr)**0.31
    return Nu
    
