import pipe81
import unittest
from pipe81 import D 

'''装于tab1中的内容，在不使用unittest的情况下，用于检验公式与实验值是否相等'''
''''T = [295.7, 303.6, 316.0, 326.6, 342.0, 356.3, 372.9, 393.6]
P = [10.5, 30, 74.4, 121, 190, 256.5, 334.6, 439.7]
v = [15.06e-6, 15.50e-6, 16.00e-6, 16.49e-6, 17.20e-6, 17.95e-6, 18.83e-6, 20.02e-6]
Pr = [0.703, 0.702, 0.701, 0.700, 0.699, 0.698, 0.697, 0.696]
landa = [0.0259, 0.0263, 0.0267, 0.0271, 0.0281, 0.0283, 0.0286, 0.0296]
h=[5.514613256791231, 7.262207547349981, 8.773389697069476, 9.630938192619384, 10.702673028336056, 11.177953023669582, 11.58826171637394, 12.166046182055528]
'''
class comparesolve(unittest.TestCase):
    def setUp(self):
        self.tab1=[[295.7, 303.6, 316.0, 326.6, 342.0, 356.3, 372.9, 393.6],[10.5, 30, 74.4, 121, 190, 256.5, 334.6, 439.7],[15.06e-6, 15.50e-6, 16.00e-6, 16.49e-6, 17.20e-6, 17.95e-6, 18.83e-6, 20.02e-6],
                   [0.703, 0.702, 0.701, 0.700, 0.699, 0.698, 0.697, 0.696],[0.0259, 0.0263, 0.0267, 0.0271, 0.0281, 0.0283, 0.0286, 0.0296],
                   [5.514613256791231, 7.262207547349981, 8.773389697069476, 9.630938192619384, 10.702673028336056, 11.177953023669582, 11.58826171637394, 12.166046182055528]]
    def testsolve1(self):
        for item in self.tab1:
            self.assertAlmostEqual(pipe.solve1(item[0],item[1],item[2],item[3]), pipe.fromhsolveNu(item[0],item[1],item[4],item[5]),6) 
    def testsolve2(self):
        for item in self.tab1:
            self.assertAlmostEqual(pipe.solve2(item[0],item[1],item[2],item[3]), pipe.fromhsolveNu(item[0],item[1],item[4],item[5]),6) 
    def testsolve3(self):
        for item in self.tab1:
            self.assertAlmostEqual(pipe.solve3(item[0],item[1],item[2],item[3]), pipe.fromhsolveNu(item[0],item[1],item[4],item[5]),6) 
    def testsolve4(self):
        for item in self.tab1:
            self.assertAlmostEqual(pipe.solve4(item[0],item[1],item[2],item[3]), pipe.fromhsolveNu(item[0],item[1],item[4],item[5]),6)
     
'''d1=[]
d2=[]
d3=[]
d4=[]       '''  
if __name__=="__main__":
    unittest.main(defaultTest='comparesolve')
    '''for i in range(0,8):   
        d1.append(pipe.solve1(T[i],P[i],v[i],Pr[i])-pipe.fromhsolveNu(T[i],P[i],landa[i],h[i]))
        d2.append(pipe.solve2(T[i],P[i],v[i],Pr[i])-pipe.fromhsolveNu(T[i],P[i],landa[i],h[i]))
        d3.append(pipe.solve3(T[i],P[i],v[i],Pr[i])-pipe.fromhsolveNu(T[i],P[i],landa[i],h[i]))
        d4.append(pipe.solve4(T[i],P[i],v[i],Pr[i])-pipe.fromhsolveNu(T[i],P[i],landa[i],h[i])) 
    print(d1) 
    print(d2)  
    print(d3)  
    print(d4)       '''          